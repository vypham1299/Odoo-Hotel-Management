from odoo import models, fields, api


class Room_2(models.Model):
    # _name = 'hotel.2'
    _inherit = 'hotel'
    _description = 'New Hotel with Extension'